<?php  
session_start();
	$conn = new mysqli("localhost","root","","proxy");
		if($conn === false )
{
	die("Error! Couldn't connect. ". $conn->connect_error );
}
?>



