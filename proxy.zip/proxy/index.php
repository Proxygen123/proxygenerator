<?php include 'connection.php'; ?>
<?php

if (isset($_POST['submit'])) {

    $user = $_POST['username'];
    $pass = $_POST['password'];

    $sql = "SELECT * FROM login WHERE Username = '$user'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    session_regenerate_id();
    $_SESSION['Fullname'] = $row['Fullname'];
    $_SESSION['username'] = $row['Username'];
    session_write_close();
if (empty($user) || empty($pass)) {
      echo '<script>alert("Please Enter Username & Password")</script>';
    }else{
        if ($row['Password'] == $pass) {
        
        header("Location:dashboard.php");

        }else{

        echo '<script>alert("Incorrect Credentials")</script>';
        }
    // code...
    }
}





 ?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/logo.png" rel="icon">
  <title>Login</title>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="assets/css/styles.css" rel="stylesheet">
</head>

<body class="bg-gradient-login">

  <div id="loader-wrapper">
      <div id="loader"></div>        
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
  </div>
  <!-- Login Content -->
  <div class="container-login mt-5">
    <div class="row justify-content-center">

        <div class="card shadow-sm my-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col-lg-12">
               
      <?php if(isset($_SESSION['response'])){ ?>
<div class="alert alert-<?= $_SESSION['type']; ?> alert-dismissible">
  <button type="button" class="close" data-dismiss="alert">&times </button>
  <?= $_SESSION['response']; ?>
  </div>
<?php  unset($_SESSION['response']); 
} ?>
    <div class="login-container">
        <!-- Left Section: Logo and Image -->
        <div class="left-section">
            <div class="logo-container">
                <img src="assets/img/school.png" alt="School Logo" class="school-logo">
            </div>
            <div class="image-container">
                <img src="assets/img/school_building.png" alt="School Building" class="school-image">
            </div>
        </div>

        <!-- Right Section: Login Form -->
        <div class="right-section">
            <form class="login-form" method="POST">
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Username">
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Password">
                </div>
                <div class="forgot-password">
                    <a href="#">Forgot Password?</a>
                </div>
                <button type="submit" name = "submit" class="login-btn">Login</button>
            </form>
        </div>
    </div>
             
                  
                </div>
              </div>
            </div>
          </div>

      </div>
    </div>
  </div>
  
  <!-- Login Content -->
  <script src="js/jquery-1.11.2.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <script src="js/plugins.min.js"></script>
</body>

</html>
<script type="text/javascript">
  $(document).ready(function() {
  $('button').click(function(){
    $('#overlay').fadeIn().delay(2000).fadeOut();
  });
});
</script>