<?php include 'connection.php'; ?>


<?php 

if (!isset($_SESSION['username'])) {
    
    header("Location:index.php");
}

require_once 'phpqrcode/qrlib.php';
$path ='qrcode/';

if (isset($_POST['add'])) {
    
    $idz = $_POST['studid'];
    $first = $_POST['fname'];
    $middle = $_POST['mname'];
    $last = $_POST['lname'];
    $suff = $_POST['suffix'];
    $gend = $_POST['gender'];
    $ages = $_POST['age'];
    $bdates = $_POST['bdate'];
    $bplaces = $_POST['bplace'];
    $conts = $_POST['cont'];
    $gnames = $_POST['gname'];
    $gconts = $_POST['gcont'];
    $ad = $_POST['adds'];
   $qr = $idz;
   $batch = date('Y');

    $imagez = $_FILES['images']['name'];
  
      $upload = "uploads/".$imagez;

    $file = $path.$idz.".png";


    $sqls = "SELECT * FROM `students` WHERE `stud_id` = '$idz'";
    $stmt = $conn->prepare($sqls);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (@$row['stud_id'] == $idz) {
       
       echo '<script>alert("Student ID is already Exist")</script>';
    }else {
     $query = "INSERT INTO `students`( `stud_id`, `First_Name`, `Middle_Name`, `Last_Name`, `Suffix`, `Gender`, `Age`, `Birth_Date`, `Birth_Place`, `Contact_Num`, `Guardian_Name`, `Guardian_Cont`,`Address`,`Photo`,`QRcode`,`Batch`) VALUES ('$idz','$first','$middle','$last','$suff','$gend','$ages','$bdates','$bplaces','$conts','$gnames','$gconts','$ad','$upload','$qr','$batch')";
    $stmts = $conn->prepare($query);
    $stmts->execute();

     QRcode::png($idz,$file);
           move_uploaded_file($_FILES['images']['tmp_name'], $upload);

    $_SESSION['response']="Information is successfully submitted";
    $_SESSION['type']="success";
       
        }


}

  if(isset($_POST['delete'])){
    $id = $_POST['myids'];
   $sqls = "INSERT into archive(SELECT * from students WHERE s_id='$id')";
    $stmt = $conn -> prepare($sqls);
    $stmt ->execute();
    $sql = "DELETE FROM students WHERE s_id='$id'";
    $stmt = $conn -> prepare($sql);
    $stmt ->execute();


          $_SESSION['response']="Information transfered to archived";
    $_SESSION['type']="danger";
    }

if (isset($_POST['gets'])) {
    $idz = $_POST['ids'];

    $qwe = "SELECT * FROM genid WHERE s_id = '$idz'";
    $stmts1 = $conn->prepare($qwe);
      $stmts1->execute();
      $rest = $stmts1->get_result();
      $roaw = $rest->fetch_assoc();

      if (@$roaw['s_id'] == $idz) {
                $_SESSION['response'] = "Information is already Generated";
    $_SESSION['type'] = "danger";  
      }else{
        $sqlsz = "INSERT INTO `genid`     (stud_id, First_Name, Middle_Name, Last_Name, Suffix, Gender, Age, Birth_Date, Birth_Place, Contact_Num, Guardian_Name, Guardian_Cont, Address, Photo, QRcode, Batch, s_id, id_status) 
     SELECT 
    stud_id, 
    First_Name, 
    Middle_Name, 
    Last_Name, 
    Suffix, 
    Gender, 
    Age, 
    Birth_Date, 
    Birth_Place, 
    Contact_Num, 
    Guardian_Name, 
    Guardian_Cont, 
    Address, 
    Photo, 
    QRcode, 
    Batch, 
    s_id,
    'UNCLAIMED'
              FROM `students` WHERE `s_id` = ? ";
    
    $stmtz = $conn->prepare($sqlsz);
    $stmtz->bind_param("s", $idz); // Bind the student ID parameter
    $stmtz->execute(); // Execute the prepared statement

    // Set a success message in the session
    $_SESSION['response'] = "Information Generated Successfully";
    $_SESSION['type'] = "success";
      }

}

if (isset($_POST['generate'])) {
    $gen = $_POST['gids'];

    // Insert data into genid table, but limit to 10 rows, only for students not existing in genid, and where `Status` = 0.
    $sqlw = "INSERT INTO genid 
    (stud_id, First_Name, Middle_Name, Last_Name, Suffix, Gender, Age, Birth_Date, Birth_Place, Contact_Num, Guardian_Name, Guardian_Cont, Address, Photo, QRcode, Batch, s_id, id_status)  
SELECT 
    stud_id, 
    First_Name, 
    Middle_Name, 
    Last_Name, 
    Suffix, 
    Gender, 
    Age, 
    Birth_Date, 
    Birth_Place, 
    Contact_Num, 
    Guardian_Name, 
    Guardian_Cont, 
    Address, 
    Photo, 
    QRcode, 
    Batch, 
    s_id,
    'UNCLAIMED'
FROM 
    students 
WHERE 
    Batch = ? 
    AND Status = 0
    AND NOT EXISTS (
        SELECT 1 
        FROM genid 
        WHERE genid.s_id = students.s_id
    )
LIMIT 10";

    // Prepare the SQL statement
    $stmtw = $conn->prepare($sqlw);

    // Check if prepare() failed
    if (!$stmtw) {
        die("SQL error: " . $conn->error); // Output any SQL error and stop execution
    }

    // Bind the selected batch parameter and execute the query
    $stmtw->bind_param("s", $gen);
    $stmtw->execute();

    // Update the status of the students that were inserted into genid
    $sqlt = "UPDATE students 
SET `Status` = '1' 
WHERE Batch = ? 
AND s_id IN (
    SELECT s_id 
    FROM genid 
    WHERE Batch = ?
)";

    // Prepare the SQL statement for the update
    $stmtt = $conn->prepare($sqlt);

    // Check if prepare() failed
    if (!$stmtt) {
        die("SQL error: " . $conn->error); // Output any SQL error and stop execution
    }

    // Bind the selected batch parameter and execute the query
    $stmtt->bind_param("ss", $gen, $gen);
    $stmtt->execute();

    // Provide feedback to the user
    $_SESSION['response'] = "Information Generated Successfully";
    $_SESSION['type'] = "success";
}



if (isset($_POST['update'])) {
    $sd = $_POST['s_ids'];
    $first = $_POST['fnames'];
    $middle = $_POST['mnames'];
    $last = $_POST['lnames'];
    @$suffs = $_POST['suffixs'];
    $gend = $_POST['genders'];
    $ages = $_POST['agezcx'];
    $bdates = $_POST['bdates'];
    $bplaces = $_POST['bplaces'];
    $conts = $_POST['conts'];
    $gnames = $_POST['gnames'];
    $gconts = $_POST['gconts'];
    $ad = $_POST['addsz'];

    // Check if a new image is uploaded
    if (!empty($_FILES['imagesz']['name'])) {
        $imagez = $_FILES['imagesz']['name'];
        $upload = "uploads/" . $imagez;

        // Move uploaded file
        move_uploaded_file($_FILES['imagesz']['tmp_name'], $upload);

        // Include the photo in the update query
        $sqlse = "UPDATE `students` SET `First_Name` = '$first', `Middle_Name` = '$middle', `Last_Name` = '$last', `Suffix` = '$suffs', `Gender` = '$gend', `Age` = '$ages', `Birth_Date` = '$bdates', `Birth_Place` = '$bplaces', `Contact_Num` = '$conts', `Guardian_Name` = '$gnames', `Guardian_Cont` = '$gconts', `Address` = '$ad', `Photo` = '$upload' WHERE `s_id` = '$sd'";
    } else {
        // If no new photo is uploaded, exclude the photo field in the update query
        $sqlse = "UPDATE `students` SET `First_Name` = '$first', `Middle_Name` = '$middle', `Last_Name` = '$last', `Suffix` = '$suffs', `Gender` = '$gend', `Age` = '$ages', `Birth_Date` = '$bdates', `Birth_Place` = '$bplaces', `Contact_Num` = '$conts', `Guardian_Name` = '$gnames', `Guardian_Cont` = '$gconts', `Address` = '$ad' WHERE `s_id` = '$sd'";
    }

    // Prepare and execute the query
    $stmtse = $conn->prepare($sqlse);
    $stmtse->execute();

    $_SESSION['response'] = "Information Updated Successfully";
    $_SESSION['type'] = "primary";
}

?>





<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Brgy Poblacion Profiling/Management System</title>

  <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
  
</head>  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
  <link href="css/spinner.css" rel="stylesheet">
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>

<body id="page-top">
  <div id="loader-wrapper">
      <div id="loader"></div>        
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
  </div>
  <?php include 'includes/navbars.php'; ?>

        <!-- Topbar -->

        <!-- Container Fluid-->
       <!-- DataTable with Hover -->
        <div class="col-lg-12">
      <?php if(isset($_SESSION['response'])){ ?>
<div class="alert alert-<?= $_SESSION['type']; ?> alert-dismissible">
  <button type="button" class="close" data-dismiss="alert">&times </button>
  <?= $_SESSION['response']; ?>
  </div>
<?php  unset($_SESSION['response']); 
} ?>
</div>
      



            <div class="col-lg-12">

              
              <div class="card mb-4">
             
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">

                  <h6 class="m-0 font-weight-bold text-primary">STUDENTS LIST</h6>
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#insert" style="margin-left: 22cm;">
  ADD STUDENTS
</button>
                  <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#generate">
  GENERATE
</button>
                </div>

                <div class="table-responsive p-3">
       
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <?php
        $query = "SELECT * FROM students";
        $stmt = $conn-> prepare($query);
        $stmt -> execute();
        $result = $stmt -> get_result();
        ?>
                    <thead class="thead-light">
                      <tr>
                         <th style="display: none;"></th>
                        <th>#</th>
                        <th>LRN</th>
                          <th>Fullname</th>
                        <th  style="display: none;">First Name</th>
                        <th  style="display: none;">Middle Name</th>
                        <th  style="display: none;">Last Name</th>
                        <th  style="display: none;">Suffix</th>
                        <th  style="display: none;">Gender</th>
                        <th  style="display: none;">Age</th>
                        <th  style="display: none;">Birth Date</th>
                        <th  style="display: none;">Birth Place </th>
                        <th  style="display: none;">Contact Number</th>
                        <th>Guardian Name</th>
                        <th>Guardian Contact</th>
                             <th  style="display: none;">Photo</th>
                     <th  style="display: none;">Photo</th>
                       <th  style="display: none;">QR</th>
                        <th>Batch</th>
                        <th>Actions</th>
                      </tr>
                    </thead>

             
                    <tbody>
  <?php
                      $i = 1;

                       while($row=$result->fetch_assoc()){  

                            $c = $row['Middle_Name'];
             $d = !empty($c) ? substr($c, 0, 1) . '.' : '';
             ?>
                    <tr>
                      <td style="display: none;"><?=$row['s_id']?></td>
                      <td><?php echo $i++ ?></td>
                      <td><?=$row['stud_id']?></td>
                      <td><?=$row['First_Name'] . " " . $d . " " . $row['Last_Name'] . " " . $row['Suffix']; ?></td>
                      <td  style="display: none;"><?=$row['First_Name']?></td>
                      <td  style="display: none;"><?=$row['Middle_Name']?></td>
                      <td  style="display: none;"><?=$row['Last_Name']?></td>
                      <td  style="display: none;"><?=$row['Suffix']?></td>
                      <td  style="display: none;"><?=$row['Gender']?></td>
                      <td  style="display: none;"> <?=$row['Age']?></td>
                      <td  style="display: none;"><?=$row['Birth_Date']?></td>
                      <td  style="display: none;"><?=$row['Birth_Place']?></td>
                      <td  style="display: none;"><?=$row['Contact_Num']?></td>
                      <td><?=$row['Guardian_Name']?></td>
                      <td><?=$row['Guardian_Cont']?></td>
                          <td style="display: none;"><?=$row['Address']?></td>
                           <td  style="display: none;"><?=$row['Photo']?></td>
                           <td  style="display: none;"><?=$row['QRcode']?></td>
                      <td><?=$row['Batch']?></td>
                  
                      <td>
                            <a href="#idmodal?edit=<?php echo $row['s_id']; ?>" title = "IDENTIFICATION"  class="idbtn badge text-success p-2">
                            <i class="fas fa-address-book fa-2x"></i></a>|
                            <a href="#editModal?update=<?php echo $row['s_id']; ?>" class="editbtn badge text-primary p-2" ><i class="fas fa-share-square fa-2x"></i></a>|
                            <a href="#deleteModals?remove=<?php echo $row['s_id']; ?>" class="delete badge text-danger p-2" ><i class="  fas fa-trash fa-2x"></i></a>                  
                        </td>
                </tr>
             <?php } ?>
                    </tbody>
                  
                  </table>
                </div>
              </div>
            </div>

             <!-- DISPLAY ID -->
  <div class="modal fade" id="idmodal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="staticBackdropLabel">Edit Resident</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
            <div id="overlays" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
     <form method="POST" id="studentForm">
               
          <input type="hidden" name="ids" id="ids" class="form-control" onfocus="handleFocus()" oninput="handleInputChange()">
        
               <div id="output"></div>



<div class="row" style="margin-left: 4.8cm;">
  <div class="col-6 div-container" style="border: solid 1px black; width: 350px; height: 560px; border: solid 4px; 
        background: 
            linear-gradient(to bottom, #88C273 30%, transparent 43%),  linear-gradient(to top, #88C273 ,transparent 43%), 
            url('assets/img/school_building.png') center top no-repeat;
        background-size: 100% 90%; flex: 0 0 38%; 
    max-width: 38%;">
        <div class="row" style="margin-top: .1cm; text-align:center ;">
            <div class="col" style="color:black;">
                <div class="row">
                <div class="col-3">
                         <img src="assets/img/school.png" width="55" height="55" style="margin-left: -.5cm;">
                </div>
                <div class="col-9">
                      <p><h3 style="font-size: 18px; margin-left: -2.3cm;"> Republic of the Philippines</h3></p>
                </div>
           
             </div>
             <div class="col" style="margin-top: -.5cm ;">
                <h3 style="  float: center; font-size: 20px;font-family: Old English Text MT;">Department of Education</h3>
                 <h4 style=" margin-top: -.2cm; float: center; font-size: 15px; ">Region XII</h4>
                 <h5 style=" margin-top: -.2cm; float: center; font-size: 15px;">Division of South Cotabato</h5>
                 <h2 style=" margin-top: -.2cm;font-weight: bold;  font-size: 13px;"><p>PABLO VALENCIA NATIONAL HIGH SCHOOL</p></h2>
                   <h4 style="margin-top: -.4cm; float: center; font-size: 12px;">Koronadal Proper, Polomolok, South Cotabato</h4>
                     </div>
            </div>
        </div>
        <div class="row" style="margin-top: .2cm; text-align:center;">
            <div class="col">
                <img id="image" width="200" height="220" style="border: solid 3px; margin-top: .7cm;">
            </div>
      
        </div>
            

    

        <div class="row">

            <div class="col-4">
                      <center><input type="text" id="fullname" class="form-control" style="width: 320px; font-size: 20px; text-align:center; color: black;  outline: none; font-weight: bold; margin-top: 1cm;  "  readonly></center>
                  <p > <input type="text"  id="stud" name = "studids"style="font-size: 25px; font-weight: bold;   margin-top: 1.1cm; background: none; border: none; text-align: center;   outline: none; margin-top: .3cm;  " readonly></p>
          

            </div>

        </div>
    

        </div>
                <div class="col-6" style="border:solid 1px black; width: 350px; height: 560px; margin-left: .5cm; background-color: #f5f5f5; border: solid 4px; flex: 0 0 38%; 
        max-width: 38%;">
            
                <div class="row" style="margin-top: 1cm; font-size: 22px; font-weight: bold; text-align: center;">
                <div class="col"style="margin-top:-.7cm;">
                
                    <p>VALIDATION</p>
                </div>
                </div>
                <div class="row" >
                <div class="col">
                    <table class="table" style="border: solid 1px;  margin-top:-.3cm;">

               <tr>
           <th colspan="6" style="text-align: center; background-color: black; color: white;">School Year</th>

        </tr>
      
<tr>
            <td>Grade 7</td>
            <td>_______</td>
             <td>Grade 10</td>
            <td>_______</td>
           
        </tr>
        <tr>
            <td>Grade 8</td>
               <td>_______</td>
             <td>Grade 11</td>
             <td>_______</td>
              
            </tr>       
             <tr>
            <td>Grade 9</td>
                <td>_______</td>
             <td>Grade 12</td>
             <td>_______</td>
              
            </tr>



                    </table>

                </div>
                <div class="row">
                      <p style="font-size: 12px; background-color: black; color: white; font-weight: bold;  margin-top:-.3cm; margin-left:1.8cm;;" align="center" >IN CASE OF EMERGENCY PLEASE NOTIFY:</p>
                            <div style="border: 1px solid black; margin-left: .6cm; text-align: center; margin-top: -.2cm; width: 328px; ">
                <p align="center">
                    <input type="text" id="gname" style="font-size: 13px; font-weight: bold;  margin-top: -.3cm; text-decoration: underline; background: none; border: none; text-align: center; outline: none;" readonly>
                </p>
                <p style="margin-top: -.5cm; font-size: 10px;">
                    <textarea id="addsz" style="resize: none; border: none; background: none; outline: none; text-align:center;" rows="2" cols="30"></textarea>
                </p>
                <p align="center" style="margin-top: -.6cm;">
                    <input type="text" id="gcont" style="font-size: 15px; font-weight: bold;  text-decoration: underline; background: none; border: none; text-align: center; outline: none;" readonly>
                </p>
            </div>
     <p style="font-size: 10px; text-align: center; margin-left:.5cm;">This ID card certifies that the holder is a bona fide student of <br>PABLO VALENCIA NATIONAL HIGH SCHOOL. Unauthorized use is prohibited.</p>
                    <img id="qrcodes" style="width: 100px; margin-left: 3.6cm; margin-top: -.2cm;">
                </div>
                <div class="row" style="margin-top: 1.2cm;">

                    
                   
                 <p style="font-size: 15px; font-weight: bold;  margin-top:-.7cm; margin-left : 3.3cm;" >ROMEO S. JERAO</p>
            <p style="font-size: 15px; font-weight: bold;  margin-top:-.5cm; margin-left : 1.8cm;" >Head Teacher - III / School Head</p>

                </div>
            </div>

        </div>
    </div>  
    <br>

   
                </div>
                <div class="modal-footer">
                     <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                  <button type="submit" name="gets" id="get" class="btn btn-primary" >Generate</button>
                </div>
              </form>
 </div>
    </div>
  </div>
</div>
</div>

        <!--END-->

          <!--MODAL FOR STUDENTS--->
  <div class="modal fade" id="insert" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="exampleModalLabel">Add Student</h5>
        <!-- Close button for the modal in Bootstrap 4 -->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" enctype="multipart/form-data">
          <div class="row">
            <div class="col">
              <label style="font-family: Courier New;">Student ID</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="studid" placeholder="Ex: 530*********" onkeypress="return /[0-9,]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">First Name</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="fname" placeholder="Ex: Juan" onkeypress="return /[a-z, ]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Middle Name</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="mname" placeholder="Ex: Dela Cruz" onkeypress="return /[a-z, ]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Last Name</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="lname" placeholder="Ex: Streigan" onkeypress="return /[a-z, ]/i.test(event.key)"/>
            </div>
          </div>
          <br>
          <div class="row">
            <div class="col">
              <label style="font-family: Courier New;">Suffix</label>
              <select style="font-family: Courier New;" name="suffix" class="form-control">
                <option value="">- Suffix -</option>
                <option value="Jr">Jr</option>
                <option value="Sr">Sr</option>
                <option value="I">I</option>
                <option value="II">II</option>
                <option value="III">III</option>
                <option value="IV">IV</option>
                <option value="V">V</option>
              </select>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Gender</label>
              <select style="font-family: Courier New;" name="gender" class="form-control">
                <option value="">- Gender -</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Age</label>
              <input style="font-family: Courier New;" type="number" class="form-control" name="age" placeholder="Age">
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Birth Date</label>
              <input style="font-family: Courier New;" type="date" class="form-control" name="bdate" placeholder="Birth Date">
            </div>
          </div>
          <br>
          <div class="row">
            <div class="col">
              <label style="font-family: Courier New;">Birth Place</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="bplace" placeholder="Ex: Polomolok South Cotabato">
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Contact Number</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="cont" placeholder="Ex: 09**********" maxlength="11" onkeypress="return /[0-9]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Guardian Name</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="gname" placeholder="Ex: Mary Jane Solatorio" onkeypress="return /[a-z, ]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Guardian Number</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="gcont" placeholder="Ex: 09**********" maxlength="11" onkeypress="return /[0-9]/i.test(event.key)"/>
            </div>
          </div><Br>
          <div class="row">
            <div class="col">
                 <label style="font-family: Courier New;">Address</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="adds" id = "adds"placeholder="Ex: Barangay Poblacion, Polomolok, South Cotabato"/>
            </div>
              
          </div>
          <br>
           
  
              <center><label style="font-family: Courier New;" class="" >Student Photo</label>
           <div class="col">
                <img id="imagePreview" src="#" alt="Image Preview" style="display: none; max-width: 300px; max-height: 300px;"/><br>
                <input type="file" name="images" id="imageInput" accept="image/*">
              </div>       </center>
          

     

          <script>
            const imageInput = document.getElementById("imageInput");
            const imagePreview = document.getElementById("imagePreview");

            imageInput.addEventListener("change", function(event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        imagePreview.src = e.target.result;
                        imagePreview.style.display = "block";
                    };
                    reader.readAsDataURL(file);
                } else {
                    imagePreview.src = "#";
                    imagePreview.style.display = "none";
                }
            });
          </script>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="add" class="btn btn-primary">Insert</button>
      </div>
    </form>
  </div>
</div>
</div>

<!---END-->


  <!--MODAL FOR EDIT HOUSEHOLD--->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="exampleModalLabel">Update Information</h5>
        <!-- Close button for the modal in Bootstrap 4 -->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" enctype="multipart/form-data">
          <div class="row">
            <div class="col">
                <input type="hidden" name="s_ids" id="s_ids">
              <label style="font-family: Courier New;">Student ID</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="studids" id="studids" readonly>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">First Name</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="fnames" id="fnames" placeholder="Ex: Juan" onkeypress="return /[a-z, ]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Middle Name</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="mnames" id="mnames" placeholder="Ex: Dela Cruz" onkeypress="return /[a-z, ]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Last Name</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="lnames" id="lnames" placeholder="Ex: Streigan" onkeypress="return /[a-z, ]/i.test(event.key)"/>
            </div>
          </div>
          <br>
          <div class="row">
            <div class="col">
              <label style="font-family: Courier New;">Suffix</label>
              <select style="font-family: Courier New;" name="suffixs" id ="suffixs" class="form-control">
                <option value="">- Suffix -</option>
                <option value="Jr.">Jr.</option>
                <option value="Sr.">Sr.</option>
                <option value="I">I</option>
                <option value="II">II</option>
                <option value="III">III</option>
                <option value="IV">IV</option>
                <option value="V">V</option>    
              </select>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Gender</label>
              <select style="font-family: Courier New;" name="genders" id = "genders"class="form-control">
                <option value="">- Gender -</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Age</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="agezcx" id="agess" >
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Birth Date</label>
              <input style="font-family: Courier New;" type="date" class="form-control" name="bdates" id = "bdates"placeholder="Birth Date">
            </div>
          </div>
          <br>
          <div class="row">
            <div class="col">
              <label style="font-family: Courier New;">Birth Place</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="bplaces" id ="bplaces" placeholder="Ex: Polomolok South Cotabato">
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Contact Number</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="conts" id="conts" placeholder="Ex: 09**********" maxlength="11" onkeypress="return /[0-9]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Guardian Name</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="gnames" id="gnames" placeholder="Ex: Mary Jane Solatorio" onkeypress="return /[a-z, ]/i.test(event.key)"/>
            </div>
            <div class="col">
              <label style="font-family: Courier New;">Guardian Number</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="gconts" id="gconts" placeholder="Ex: 09**********" maxlength="11" onkeypress="return /[0-9]/i.test(event.key)"/>
            </div>
          </div><Br>
          <div class="row">
            <div class="col">
                 <label style="font-family: Courier New;">Address</label>
              <input style="font-family: Courier New;" type="text" class="form-control" name="addsz" id = "addszs" placeholder="Ex: Barangay Poblacion, Polomolok, South Cotabato"/>
            </div>
              
          </div>
          <br>
       
          
                <center><label style="font-family: Courier New;">Student Photo</label>
              <div class="col">
                <img id="imagePreviewsd" src="#" alt="Image Preview" style="display: none; max-width: 300px; max-height: 300px;"/><br>
                <input type="file" name="imagesz" id="imageInputsd" accept="image/*">
              </div>
            </center>
    


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="update" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</div>
</div>
<!---END-->


 


 <!-- Modal delete -->

 <div class="modal fade" id="deleteModals" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                         <div id="overlay2" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
                  <form action="" method="post">
                  <input type="hidden" name="myids" id="myids">
                  <center><p>Are you sure you want to archive this data?</p>
                    <h4><b>Student Name:</b></h4><h4 id="dataa"></h4></center>
                    
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <button type="submit" class="deleteb btn btn-danger" name="delete">Delete</button>
                </div>
          </form>
              </div>
            </div>
          </div>

          <!-- END -->
<script>
 function callme(s) {
  if (!s) {
    document.getElementById("mine").innerHTML = ''; // Clear content if no batch is selected
    return;
  }
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4) {
      if (this.status == 200) {
        document.getElementById("mine").innerHTML = this.responseText;
      } else {
        console.error("Error fetching data:", this.statusText);
      }
    }
  };
  xmlhttp.open("GET", "fetch.php?in=" + encodeURIComponent(s), true);
  xmlhttp.send();
}
</script>

<!-- Modal for generating IDs by Batch -->
<div class="modal fade" id="generate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content" >
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title" id="exampleModalLabelLogout">Generate ID by Batch</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body"  id="modalContent">
        <!-- Loading Spinner -->
        <div id="overlay2" style="display: none;">
          <div class="spinner"></div>
          <br/>
          Loading...
        </div>

        <form action="" method="post">
          <?php
            // Query to get all batches from the database
            $sql = "SELECT Batch, COUNT(*) FROM students GROUP BY Batch LIMIT 10";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->get_result();
          ?>
          <!-- Batch selection dropdown -->

            <label style="font-family: Courier New; font-size: 25px; font-weight: bold;">BATCH</label>
            <select class="form-control" name="gids" id="gids" onchange="return callme(this.value);">
              <option value="">-SELECT BATCH-</option>
              <?php while ($row = $result->fetch_assoc()) { ?>
                <option value="<?php echo htmlspecialchars($row['Batch']); ?>"><?php echo htmlspecialchars($row['Batch']); ?></option>
                <?php } ?>
            </select>
            
            
          <center>
          </center>
<br>
          <!-- AJAX Response Content -->
          <div id="mine"></div>
      
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                 <button type="button" class="btn btn-info" onclick="printModalContent()">Print</button>
       <button type="submit" class="btn btn-warning"  id = 'generate' name="generate">Generate</button>
      </div>
        </form>
    </div>
  </div>
</div>

<script>
  // Fetch data dynamically for the selected batch
function printModalContent() {
  const modalContent = document.querySelector("#modalContent");
  if (!modalContent) {
    console.error("Modal content not found.");
    return;
  }

  // Temporarily adjust the modal style to fit all content
  const originalHeight = modalContent.style.height;
  const originalOverflow = modalContent.style.overflow;

  modalContent.style.height = "auto";
  modalContent.style.overflow = "visible";

  // Use html2canvas to capture the entire content
  html2canvas(modalContent, { useCORS: true, scale: 2 }).then((canvas) => {
    // Convert the canvas to a PNG data URL
    const imgData = canvas.toDataURL("image/png");

    // Restore the original modal styles
    modalContent.style.height = originalHeight;
    modalContent.style.overflow = originalOverflow;

    // Create an anchor element to trigger the download
    const link = document.createElement("a");
    link.href = imgData;
    link.download = "ModalContent.png"; // Specify the file name for download

    // Trigger the download
    link.click();
  });
}

function handleBatchSelection(selectElement) {
  const batchSelectionDiv = document.getElementById('batch-selection');

  // Get the selected value
  const selectedValue = selectElement.value;

  // Check if a valid option is selected
  if (selectedValue) {
    // Hide the batch selection section
    batchSelectionDiv.style.display = 'none';

    // Call your existing function (if needed)
    callme(selectedValue);
  }
}

</script>


          <!-- Modal Logout -->
          <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                     <div class="modal-body">
                      <div id="overlays1" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
                  <p>Are you sure you want to logout?</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <a href="logout.php" class="logout btn btn-primary">Logout</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>copyright &copy; <script> document.write(new Date().getFullYear()); </script> - developed by
              <b><a  target="_blank"><?php echo $_SESSION['Fullname']; ?></a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
  
  <!-- Page level custom scripts -->
  <script>
    $(document).ready(function () {

      $('#dataTable').DataTable(); 
      $('#dataTableHover').DataTable();


  $(document).on('click', '.delete', function (e) {
      $('#deleteModals').modal('show');
      $tr = $(this).closest('tr');
      var data= $tr.children("td").map(function(){
        return $(this).text();

      }).get();
      console.log(data);
          let fullNamez = `${data[4]}  ${data[5].charAt(0)}. ${data[6] } ${data[7]}`;
      $('#dataa').html(fullNamez);
      $('#myids').val(data[0]);
      });

$(document).on('click', '.idbtn', function (e) {
    $('#idmodal').modal('show');
    $tr = $(this).closest('tr');
    var data = $tr.children("td").map(function(){
        return $(this).text();
    }).get();
    console.log(data);
    $('#ids').val(data[0]); 
      $('#stud').val('LRN : ' + data[2]);
          let fullName = `${data[4]}  ${data[5].charAt(0)}. ${data[6] } ${data[7]}`;
    $('#fullname').val(fullName);
        $('#gname').val(data[13]);
    $('#gcont').val(data[14]);
       $('#addsz').val(data[15]);
     $('#image').attr('src', data[16]);
     $('#qrcodes').attr('src', 'qrcode/' + data[17]);// Set the value of the input with id="ids"
});

  $(document).on('click', '.editbtn', function (e) {
    $('#editModal').modal('show');
    $tr = $(this).closest('tr');
    var data = $tr.children("td").map(function(){
        return $(this).text();
    }).get();
    console.log(data);
    
    $('#s_ids').val(data[0]); 
    $('#studids').val(data[2]); 
    $('#fnames').val(data[4]); 
    $('#mnames').val(data[5]); 
    $('#lnames').val(data[6]); 
    $('#suffixs').val(data[7]); 
    $('#genders').val(data[8]); 
    $('#agess').val(data[9]); 
    $('#bdates').val(data[10]);
    $('#bplaces').val(data[11]); 
    $('#conts').val(data[12]); 
    $('#gnames').val(data[13]); 
    $('#gconts').val(data[14]); 
    $('#addszs').val(data[15]); 
    
    // Set image preview from the table data
    const photoUrl = data[16];  // Assuming the photo URL is in the 17th column (index 16)
    if (photoUrl) {
        $('#imagePreviewsd').attr('src', photoUrl).show();
    } else {
        $('#imagePreviewsd').hide();
    }
    
    // Update the file input to reset the image preview if the user selects a new file
    $('#imageInputsd').val(''); // Clear previous file input
    $('#imageInputsd').on('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreviewsd').attr('src', e.target.result).show();
            };
            reader.readAsDataURL(file);
        } else {
            $('#imagePreviewsd').hide();
        }
    });
});

});
</script>

<script>
    let typingTimer;
    const typingDelay = 1000; // Delay in milliseconds (1 second)

    function handleFocus() {
        clearTimeout(typingTimer); // Clear any previous timer
        typingTimer = setTimeout(submitForm, typingDelay); // Set a timer to submit after delay
    }

    function handleInputChange() {
        clearTimeout(typingTimer); // Clear the previous timer on input
        typingTimer = setTimeout(submitForm, typingDelay); // Set a new timer
    }

    function submitForm() {
        document.getElementById("studentForm").submit(); // Submit the form
    }
</script>


  <script type="text/javascript">
  $(document).ready(function() {
  $('.submit').click(function(){
    $('#overlay').fadeIn().delay(2000).fadeOut();
  });
  $('.update').click(function(){
    $('#overlays').fadeIn().delay(2000).fadeOut();
  });
   $('.deleteb').click(function(){
    $('#overlay2').fadeIn().delay(2000).fadeOut();
  });
  $('.logout').click(function(){
    $('#overlays1').fadeIn().delay(2000).fadeOut();
  });
});
</script>
 <style type="text/css">
   th{
    font-size: 12px;
   }
   td{
    font-size: 13px;
   }
   #overlay {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlay2 {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlays1 {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlays {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}

.spinner {
    margin: 0 auto;
    height: 64px;
    width: 64px;
    animation: rotate 0.8s infinite linear;
    border: 5px solid firebrick;
    border-right-color: transparent;
    border-radius: 50%;
}
@keyframes rotate {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}
 </style>

 <style type="text/css">
    .div-container {
    border: solid 4px black;
    width: 150px;
    height: 50px;
    background-image: url('assets/img/school_building.png');

    background-position: center; /* This centers the image within the div */
}
</style>

</body>

</html>