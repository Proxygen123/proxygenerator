<?php include 'connection.php'; 

if (!isset($_SESSION['username'])) {
    
    header("Location:index.php");
}

if (isset($_POST['updatess'])) {

    $idz = $_POST['ids'];
    $status = 'CLAIMED';

    $sqls = "SELECT * FROM genid WHERE id_num = '$idz'";
    $stmts = $conn->prepare($sqls);
    $stmts->execute();
    $result = $stmts->get_result();
    $row = $result->fetch_assoc();

    if ($row['id_status'] == 'CLAIMED') {

        $_SESSION['response']="ID is already CLAIMED";
        $_SESSION['type']="danger";
    }else{

        $sql = "UPDATE `genid` SET `id_status`='$status' WHERE id_num ='$idz'";
        $stmt = $conn->prepare($sql);
        $stmt->execute();

          $_SESSION['response']="Status has been updated!";
    $_SESSION['type']="primary";
    }
}
if (isset($_POST['delete'])) {

      $id = $_POST['myids'];
      $stud = $_POST['studid'];

          $sqlz = "UPDATE students SET `Status` = 0 WHERE stud_id = '$stud'";
        $stmt1 = $conn -> prepare($sqlz);
    $stmt1 ->execute();

    $sql = "DELETE FROM genid WHERE id_num='$id'";
    $stmt = $conn -> prepare($sql);
    $stmt ->execute();


          $_SESSION['response']="Data has been removed";
    $_SESSION['type']="danger";
    }
?>





<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Brgy Poblacion Profiling/Management System</title>

  <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
  
</head>  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
  <link href="css/spinner.css" rel="stylesheet">
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

<body id="page-top">

  <div id="loader-wrapper">
      <div id="loader"></div>        
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
  </div>
  <?php include 'includes/navbars.php'; ?>

        <!-- Topbar -->

        <!-- Container Fluid-->
       <!-- DataTable with Hover -->
        <div class="col-lg-12">
      <?php if(isset($_SESSION['response'])){ ?>
<div class="alert alert-<?= $_SESSION['type']; ?> alert-dismissible">
  <button type="button" class="close" data-dismiss="alert">&times </button>
  <?= $_SESSION['response']; ?>
  </div>
<?php  unset($_SESSION['response']); 
} ?>
</div>
      



            <div class="col-lg-12">

              
              <div class="card mb-4">
             
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
          <h6 class="m-0 font-weight-bold text-primary">STUDENTS ID</h6>
             
                </div>
                <div class="row">
                        <div class="col-xl-3">

                            <?php 



                            $sql = "SELECT Batch, COUNT(*) FROM genid GROUP BY Batch";
                            $stmt= $conn->prepare($sql);
                            $stmt->execute();
                            $result = $stmt->get_result();


                            ?>
                              <form  method="get">
                            <select class="form-control" name="gets" id="gets" onchange="return me();">
                                <option>-SELECT BATCH-</option>

                                <?php while ($row=$result->fetch_assoc()) { ?>
                                    <?php $cat = $row['Batch'] ?>
                               <option value="<?php echo $cat; ?>" > <?php echo $cat; ?></option>
                           <?php }?>
                            </select>
                        </div>
                            <div class="col-xl-3">
                              <button type="submit" class="btn btn-primary " name="searchssz" style="margin-top: 2px; margin-left: -.5cm;"> <i class="fas fa-search fa-1x"></i></button>
              
                        </div>
                              </form>
                          </div>
                <div class="table-responsive p-3">
       
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                
                            <?php 
                       if (isset($_GET['gets'])) {
    $batch = $_GET['gets'];
    $sqls = "SELECT * FROM `genid` WHERE Batch = ?";
    $stmts = $conn->prepare($sqls);
    $stmts->bind_param("s", $batch);
    $stmts->execute();
    $rs = $stmts->get_result();
    $hasData = $rs->num_rows > 0;  // Check if there are any results
    ?>
                    <thead>
                    <tr>
                     <th style="display: none;"></th>
                        <th>#</th>
                        <th>LRN</th>
                          <th>Fullname</th>
                        <th  style="display: none;">First Name</th>
                        <th  style="display: none;">Middle Name</th>
                        <th  style="display: none;">Last Name</th>
                        <th  style="display: none;">Suffix</th>
                        <th  style="display: none;">Gender</th>
                        <th  style="display: none;">Age</th>
                        <th  style="display: none;">Birth Date</th>
                        <th  style="display: none;">Birth Place </th>
                        <th  style="display: none;">Contact Number</th>
                        <th>Guardian Name</th>
                        <th>Guardian Contact</th>
                             <th  style="display: none;">Photo</th>
                     <th  style="display: none;">Photo</th>
                       <th  style="display: none;">QR</th>
                        <th>Batch</th>
                           <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

             
                   <tbody>
                    <?php 
                    if ($hasData) {
                        $i = 1;
                        while ($rows = $rs->fetch_assoc()) { 
                                   $c = $rows['Middle_Name'];
             $d = !empty($c) ? substr($c, 0, 1) . '.' : '';
             ?>
                            <tr>
                                                     <td style="display: none;"><?=$rows['id_num']?></td>
                      <td><?php echo $i++ ?></td>
                      <td><?=$rows['stud_id']?></td>
                      <td><?=$rows['First_Name'] . " " . $d . " " . $rows['Last_Name'] . " " . $rows['Suffix']; ?></td>
                      <td  style="display: none;"><?=$rows['First_Name']?></td>
                      <td  style="display: none;"><?=$rows['Middle_Name']?></td>
                      <td  style="display: none;"><?=$rows['Last_Name']?></td>
                      <td  style="display: none;"><?=$rows['Suffix']?></td>
                      <td  style="display: none;"><?=$rows['Gender']?></td>
                      <td  style="display: none;"> <?=$rows['Age']?></td>
                      <td  style="display: none;"><?=$rows['Birth_Date']?></td>
                      <td  style="display: none;"><?=$rows['Birth_Place']?></td>
                      <td  style="display: none;"><?=$rows['Contact_Num']?></td>
                      <td><?=$rows['Guardian_Name']?></td>
                      <td><?=$rows['Guardian_Cont']?></td>
                          <td style="display: none;"><?=$rows['Address']?></td>
                           <td  style="display: none;"><?=$rows['Photo']?></td>
                           <td  style="display: none;"><?=$rows['QRcode']?></td>
                      <td><?=$rows['Batch']?></td>
                           <td><?=$rows['id_status']?></td>
                                <td>
                            <a href="#idmodal?edit=<?php echo $rows['id_num']; ?>"  class="idbtn badge text-success">
                               <i class="fas fa-address-book fa-3x"></i></a>|</a>
                            <a href="#deleteModals?delete=<?php echo $rows['id_num']; ?>" style = "text-decoration: none;" class="editbtn badge text-danger" ><i class="  fas fa-trash fa-2x"></i> </a>
                         
                                </td>
                            </tr>
                        <?php } 
                    } else if(!isset($_GET['searchssz'])) { ?>
                        <?php  echo '<tr>
                            <td colspan="8" class="text-center">No records found.</td>
                        </tr>';
                        ?>
                    <?php } ?>
                </tbody>
                  <?php 
}
?>
                  </table>
    <?php

     if (!isset($_GET['gets'])) {
         
         echo '             <div class="card mb-4" style="margin-top: .5cm ;">


                            <div class="card-body table-responsive">
                                <table id="datatablesSimple" class="table table-hover table-bordered ">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Student ID</th>
                                            <th>Fullname</th>
                                            <th>Birth Date</th>
                                            <th>Guardian Name</th>
                                            <th>Guardian Contact</th>
                                            <th>Batch</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                       
                                     
                                                    
                                    <tbody>
                                            <td colspan ="8" align ="center">No data available in table</td>

                                           
                                                  
                                    </tbody>
                                </table>
                            </div>
                        </div>';
     }


    ?>            
                </div>

    
              </div>

            </div>

             <!-- DISPLAY ID -->
  <div class="modal fade" id="idmodal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="staticBackdropLabel">Update Status!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
            <div id="overlays" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
     <form method="POST" id="studentForm">
               
          <input type="hidden" name="ids" id="ids" class="form-control" onfocus="handleFocus()" oninput="handleInputChange()">
        
               <div id="output"></div>



<div class="row" style="margin-left: 4.8cm;">
  <div class="col-6 div-container" style="border: solid 1px black; width: 350px; height: 560px; border: solid 4px; 
        background: 
            linear-gradient(to bottom, #88C273 30%, transparent 43%),  linear-gradient(to top, #88C273 ,transparent 43%), 
            url('assets/img/school_building.png') center top no-repeat;
        background-size: 100% 90%; flex: 0 0 38%; 
    max-width: 38%;">
        <div class="row" style="margin-top: .1cm; text-align:center ;">
        <div class="col" style="color:black;">
                <div class="row">
                <div class="col-3">
                         <img src="assets/img/school.png" width="55" height="55" style="margin-left: -.5cm;">
                </div>
                <div class="col-9">
                                  <p><h3 style="font-size: 18px; margin-left: -2.3cm;"> Republic of the Philippines</h3></p>
                </div>
           
             </div>
             <div class="col" style="margin-top: -.5cm ;">
                <h3 style="  float: center; font-size: 20px;font-family: Old English Text MT;">Department of Education</h3>
                 <h4 style=" margin-top: -.2cm; float: center; font-size: 15px; ">Region XII</h4>
                 <h5 style=" margin-top: -.2cm; float: center; font-size: 15px;">Division of South Cotabato</h5>
                 <h2 style=" margin-top: -.2cm;font-weight: bold;  font-size: 13px;"><p>PABLO VALENCIA NATIONAL HIGH SCHOOL</p></h2>
                   <h4 style="margin-top: -.4cm; float: center; font-size: 12px;">Koronadal Proper, Polomolok, South Cotabato</h4>
                     </div>
            </div>
        </div>
        <div class="row" style="margin-top: .2cm; text-align:center;">
            <div class="col">
                <img id="image" width="200" height="220" style="border: solid 3px; margin-top: .7cm;">
            </div>
      
        </div>
            

    

        <div class="row">

            <div class="col-4">
                      <center><input type="text" id="fullname" class="form-control" style="width: 320px; font-size: 20px; text-align:center; color: black;  outline: none; font-weight: bold; margin-top: 1cm;  "  readonly></center>
                  <p > <input type="text"  id="stud" name = "studids"style="font-size: 25px; font-weight: bold;   margin-top: 1.1cm; background: none; border: none; text-align: center;   outline: none; margin-top: .3cm;  " readonly></p>
          

            </div>

        </div>
    

        </div>
                <div class="col-6" style="border:solid 1px black; width: 350px; height: 560px; margin-left: .5cm; background-color: #f5f5f5; border: solid 4px; flex: 0 0 38%; 
        max-width: 38%;">
            
                <div class="row" style="margin-top: 1cm; font-size: 22px; font-weight: bold; text-align: center;">
                <div class="col"style="margin-top:-.7cm;">
                
                    <p>VALIDATION</p>
                </div>
                </div>
                <div class="row" >
                <div class="col">
                    <table class="table" style="border: solid 1px;  margin-top:-.3cm;">

               <tr>
           <th colspan="6" style="text-align: center; background-color: black; color: white;">School Year</th>

        </tr>
      
<tr>
            <td>Grade 7</td>
            <td>_______</td>
             <td>Grade 10</td>
            <td>_______</td>
           
        </tr>
        <tr>
            <td>Grade 8</td>
               <td>_______</td>
             <td>Grade 11</td>
             <td>_______</td>
              
            </tr>       
             <tr>
            <td>Grade 9</td>
                <td>_______</td>
             <td>Grade 12</td>
             <td>_______</td>
              
            </tr>



                    </table>

                </div>
                <div class="row">
                      <p style="font-size: 12px; background-color: black; color: white; font-weight: bold;  margin-top:-.3cm; margin-left:1.8cm;;" align="center" >IN CASE OF EMERGENCY PLEASE NOTIFY:</p>
                            <div style="border: 1px solid black; margin-left: .6cm; text-align: center; margin-top: -.2cm; width: 328px; ">
                <p align="center">
                    <input type="text" id="gname" style="font-size: 13px; font-weight: bold;  margin-top: -.3cm; text-decoration: underline; background: none; border: none; text-align: center; outline: none;" readonly>
                </p>
                <p style="margin-top: -.5cm; font-size: 10px;">
                    <textarea id="addsz" style="resize: none; border: none; background: none; outline: none; text-align:center;" rows="2" cols="30"></textarea>
                </p>
                <p align="center" style="margin-top: -.6cm;">
                    <input type="text" id="gcont" style="font-size: 15px; font-weight: bold;  text-decoration: underline; background: none; border: none; text-align: center; outline: none;" readonly>
                </p>
            </div>
     <p style="font-size: 10px; text-align: center; margin-left:.5cm;">This ID card certifies that the holder is a bona fide student of <br>PABLO VALENCIA NATIONAL HIGH SCHOOL. Unauthorized use is prohibited.</p>
                    <img id="qrcodes" style="width: 100px; margin-left: 3.6cm; margin-top: -.2cm;">
                </div>
                <div class="row" style="margin-top: 1.2cm;">

                    
                   
                 <p style="font-size: 15px; font-weight: bold;  margin-top:-.7cm; margin-left : 3.3cm;" >ROMEO S. JERAO</p>
            <p style="font-size: 15px; font-weight: bold;  margin-top:-.5cm; margin-left : 1.8cm;" >Head Teacher - III / School Head</p>

                </div>
            </div>

        </div>
    </div>  
    <br>

   
                </div>
                <div class="modal-footer">
                     <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                  <button type="submit" name="updatess" id="get" class="btn btn-primary" >Update</button>
                </div>
              </form>
 </div>
    </div>
  </div>
</div>
</div>
        <!--END-->

          <!--MODAL FOR STUDENTS--->


<!---END-->


  <!--MODAL FOR EDIT HOUSEHOLD--->
  <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                  <h5 class="modal-title" id="exampleModalLabelLogout">ID STATUS!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                         <div id="overlay2" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
                  <form action="" method="post">
                    <input type="hidden" name="studid" id="studid"> 
                  <input type="hidden" name="myids" id="myids">
                  <center><p>Are you sure you want to remove this data?</p>
                    <h4><b>Student Name:</b></h4><h4 id="dataa"></h4><br>
                   
               
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <button type="submit" class="deleteb btn btn-danger" name="delete">Delete</button>
                </div>
          </form>
              </div>
            </div>
          </div>
<!---END-->


 


 <!-- Modal delete -->


          <!-- END -->


<!-- Modal for generating IDs by Batch -->
>


          <!-- Modal Logout -->
          <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                     <div class="modal-body">
                      <div id="overlays1" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
                  <p>Are you sure you want to logout?</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <a href="logout.php" class="logout btn btn-primary">Logout</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>copyright &copy; <script> document.write(new Date().getFullYear()); </script> - developed by
              <b><a  target="_blank"><?php echo $_SESSION['Fullname']; ?></a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
  
  <!-- Page level custom scripts -->
  <script>
    $(document).ready(function () {

      $('#dataTable').DataTable(); 
      $('#dataTableHover').DataTable();

$(document).on('click', '.editbtn', function (e) {
      $('#editModal').modal('show');
      $tr = $(this).closest('tr');
      var data= $tr.children("td").map(function(){
        return $(this).text();

      }).get();
      console.log(data);
          let fullNamez = `${data[4]}  ${data[5].charAt(0)}. ${data[6] } ${data[7]}`;
      $('#dataa').html(fullNamez);
      $('#myids').val(data[0]);
       $('#studid').val(data[2]);
      });

$(document).on('click', '.idbtn', function (e) {
    $('#idmodal').modal('show');
    $tr = $(this).closest('tr');
    var data = $tr.children("td").map(function(){
        return $(this).text();
    }).get();
    console.log(data);
    $('#ids').val(data[0]); 
      $('#stud').val('LRN : ' + data[2]);
          let fullName = `${data[4]}  ${data[5].charAt(0)}. ${data[6] } ${data[7]}`;
    $('#fullname').val(fullName);
        $('#gname').val(data[13]);
    $('#gcont').val(data[14]);
       $('#addsz').val(data[15]);
     $('#image').attr('src', data[16]);
     $('#qrcodes').attr('src', 'qrcode/' + data[17]);// Set the value of the input with id="ids"
});
});
</script>



  <script type="text/javascript">
  $(document).ready(function() {
  $('.submit').click(function(){
    $('#overlay').fadeIn().delay(2000).fadeOut();
  });
  $('.update').click(function(){
    $('#overlays').fadeIn().delay(2000).fadeOut();
  });
   $('.deleteb').click(function(){
    $('#overlay2').fadeIn().delay(2000).fadeOut();
  });
  $('.logout').click(function(){
    $('#overlays1').fadeIn().delay(2000).fadeOut();
  });
});
</script>
 <style type="text/css">
   th{
    font-size: 12px;
   }
   td{
    font-size: 13px;
   }
   #overlay {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlay2 {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlays1 {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlays {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}

.spinner {
    margin: 0 auto;
    height: 64px;
    width: 64px;
    animation: rotate 0.8s infinite linear;
    border: 5px solid firebrick;
    border-right-color: transparent;
    border-radius: 50%;
}
@keyframes rotate {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}
 </style>

 <style type="text/css">
    .div-container {
    border: solid 4px black;
    width: 150px;
    height: 50px;
    background-image: url('assets/img/school_building.png');

    background-position: center; /* This centers the image within the div */
}
</style>

</body>

</html>