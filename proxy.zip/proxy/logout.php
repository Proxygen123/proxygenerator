<?php 
session_unset();
session_destroy();

header("Location:index.php");
    $_SESSION['response']="Successfully Logout";
    $_SESSION['type']="success";


?>