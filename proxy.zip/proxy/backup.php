<?php
include 'connection.php';

if (isset($_POST['backup'])) {
    define("DB_USER", 'root');
    define("DB_PASSWORD", '');
    define("DB_NAME", 'proxy'); // Change to your database name
    define("DB_HOST", 'localhost');
    define("BACKUP_DIR", 'database/'); // Directory where backups will be stored
    define("TABLES", '*'); // Full backup
    define('IGNORE_TABLES', array()); // Tables to ignore during backup
    define("CHARSET", 'utf8');
    define("GZIP_BACKUP_FILE", false); // Set to true for gzipped backups
    define("DISABLE_FOREIGN_KEY_CHECKS", true); // Disable foreign key checks during backup
    define("BATCH_SIZE", 1000); // Number of rows per INSERT statement in backup file

    /**
     * Class to handle database backups
     */
    class Backup_Database {
        private $host;
        private $username;
        private $password;
        private $dbName;
        private $charset;
        private $conn;
        private $backupDir;
        private $backupFile;
        private $gzipBackupFile;
        private $disableForeignKeyChecks;
        private $batchSize;

        public function __construct($host, $username, $password, $dbName, $charset = 'utf8') {
            $this->host = $host;
            $this->username = $username;
            $this->password = $password;
            $this->dbName = $dbName;
            $this->charset = $charset;
            $this->conn = $this->initializeDatabase();
            $this->backupDir = BACKUP_DIR ? BACKUP_DIR : '.';
            $this->backupFile = $this->dbName . '-' . date("Ymd_His") . '.sql';
            $this->gzipBackupFile = GZIP_BACKUP_FILE;
            $this->disableForeignKeyChecks = DISABLE_FOREIGN_KEY_CHECKS;
            $this->batchSize = BATCH_SIZE;
        }

        private function initializeDatabase() {
            $conn = mysqli_connect($this->host, $this->username, $this->password, $this->dbName);
            if (!$conn) {
                die("ERROR: Unable to connect to the database: " . mysqli_connect_error());
            }
            mysqli_set_charset($conn, $this->charset);
            return $conn;
        }

        public function backupTables($tables = '*') {
            if ($tables === '*') {
                $tables = array();
                $result = mysqli_query($this->conn, 'SHOW TABLES');
                if (!$result) {
                    die('ERROR: Could not fetch table list: ' . mysqli_error($this->conn));
                }
                while ($row = mysqli_fetch_row($result)) {
                    $tables[] = $row[0];
                }
            } else {
                $tables = is_array($tables) ? $tables : explode(',', $tables);
            }

            $sql = "CREATE DATABASE IF NOT EXISTS `{$this->dbName}`;\n\n";
            $sql .= "USE `{$this->dbName}`;\n\n";

            if ($this->disableForeignKeyChecks) {
                $sql .= "SET foreign_key_checks = 0;\n\n";
            }

            foreach ($tables as $table) {
                if (in_array($table, IGNORE_TABLES)) {
                    continue;
                }

                $sql .= "DROP TABLE IF EXISTS `{$table}`;\n";
                $createTableResult = mysqli_query($this->conn, "SHOW CREATE TABLE `{$table}`");
                if (!$createTableResult) {
                    die('ERROR: Could not fetch CREATE TABLE for ' . $table . ': ' . mysqli_error($this->conn));
                }
                $row = mysqli_fetch_row($createTableResult);
                $sql .= "{$row[1]};\n\n";

                $numRowsResult = mysqli_query($this->conn, "SELECT COUNT(*) FROM `{$table}`");
                $numRows = mysqli_fetch_row($numRowsResult)[0];

                $numBatches = ceil($numRows / $this->batchSize);

                for ($i = 0; $i < $numBatches; $i++) {
                    $offset = $i * $this->batchSize;
                    $result = mysqli_query($this->conn, "SELECT * FROM `{$table}` LIMIT {$offset}, {$this->batchSize}");
                    if (!$result) {
                        die('ERROR: Could not fetch data from table ' . $table . ': ' . mysqli_error($this->conn));
                    }
                    $fieldsCount = mysqli_num_fields($result);

                    if (mysqli_num_rows($result) > 0) {
                        $sql .= "INSERT INTO `{$table}` VALUES ";
                        $rowCount = 0;

                        while ($row = mysqli_fetch_row($result)) {
                            $sql .= '(';
                            for ($j = 0; $j < $fieldsCount; $j++) {
                                $value = isset($row[$j]) ? addslashes($row[$j]) : 'NULL';
                                $sql .= is_numeric($value) ? $value : "'{$value}'";
                                if ($j < $fieldsCount - 1) {
                                    $sql .= ',';
                                }
                            }
                            $sql .= ')';
                            $rowCount++;
                            $sql .= ($rowCount == mysqli_num_rows($result)) ? ";\n" : ",\n";
                        }
                    }
                }
                $sql .= "\n\n";
            }

            if ($this->disableForeignKeyChecks) {
                $sql .= "SET foreign_key_checks = 1;\n";
            }

            return $this->saveFile($sql);
        }

        private function saveFile($sql) {
            if (!is_dir($this->backupDir)) {
                if (!mkdir($this->backupDir, 0777, true)) {
                    die("ERROR: Could not create backup directory.");
                }
            }

            $filePath = $this->backupDir . '/' . $this->backupFile;

            if (file_put_contents($filePath, $sql)) {
                return true;
            } else {
                die("ERROR: Could not save backup file.");
            }
        }
    }

    // Perform the backup
    $backup = new Backup_Database(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, CHARSET);

    if ($backup->backupTables(TABLES)) {
        // Redirect to settings page after successful backup
        header("Location: settings.php");
            $_SESSION['response'] = "Database Successfully backup";
    $_SESSION['type'] = "success";
        exit;
    } else {
        // Show an alert if backup fails
        echo "<script>alert('Backup failed! Please try again.');</script>";
    }
}
?>
