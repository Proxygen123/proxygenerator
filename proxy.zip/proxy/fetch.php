<?php include 'connection.php'; ?>
<?php


    $input = $_GET['in'];
    $query = "SELECT * FROM students WHERE Batch = ? AND `Status` = 0 LIMIT 10";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $input);
    $stmt->execute();
    $result = $stmt->get_result();

    foreach ($result as $row) {
  
        echo '
          <input type="hidden" name="stats" value="LRN : ' . $row["Status"] . '" id="stats">
<div class="row" style="margin-left: 4.8cm;">
  <div class="col div-container" style="border: solid 1px black; width: 350px; height: 560px; border: solid 4px; 
        background: 
            linear-gradient(to bottom, #88C273 30%, transparent 43%),  linear-gradient(to top, #88C273 ,transparent 43%), 
            url(\'assets/img/school_building.png\') center top no-repeat;
        background-size: 100% 90%;   flex: 0 0 38%; 
    max-width: 38%;">
        <div class="row" style="margin-top: .1cm; text-align:center;">
        <div class="col" style="color:black;">
                <div class="row">
                    <div class="col-3">
                         <img src="assets/img/school.png" width="55" height="55" style="margin-left: -.5cm;">
                    </div>
                    <div class="col-9">
                      <p><h3 style="font-size: 18px; margin-left: -2.3cm;"> Republic of the Philippines</h3></p>
                    </div>
                </div>
                <div class="col" style="margin-top: -.5cm;">
                    <h3 style="font-family: Old English Text MT; font-size: 20px;">Department of Education</h3>
                    <h4 style="font-size: 15px; margin-top: -.2cm;">Region XII</h4>
                    <h5 style="font-size: 15px; margin-top: -.2cm;">Division of South Cotabato</h5>
                    <h2 style="font-weight: bold; font-size: 13px; margin-top: -.2cm;">PABLO VALENCIA NATIONAL HIGH SCHOOL</h2>
                    <h4 style="font-size: 12px; margin-top: -.3cm;">Koronadal Proper, Polomolok, South Cotabato</h4>
                </div>
            </div>
        </div>
        <div class="row" style="margin-top: .2cm; text-align:center;">
            <div class="col">
                <img id="image" width="200" src="' . $row["Photo"] . '" height="220" style="border: solid 3px; margin-top: .7cm;">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <center>
                    <input type="text" id="fullname" class="form-control" style="width: 320px; font-size: 18px; text-align:center; color: black; outline: none; font-weight: bold; margin-top: 1cm;" value="' . $row["First_Name"] . ' ' . $row["Middle_Name"] . ' ' . $row["Last_Name"] . ' ' . $row["Suffix"] . '" readonly>
                </center>
                <p>
                    <input type="text" id="stud" value="LRN : ' . $row["stud_id"] . '" name="studids" style="font-size: 25px; font-weight: bold; outline: none;margin-top: .6cm; background: none; border: none; text-align: center; outline: none;" readonly>
                </p>
            </div>
        </div>
    </div>
    <div class="col-6" style="border:solid 1px black; width: 350px; height: 560px; margin-left: .5cm; background-color: #f5f5f5; border: solid 4px; flex: 0 0 38%; 
    max-width: 38%;">
        <div class="row" style="margin-top: 1cm; font-size: 22px; font-weight: bold; text-align: center;">
            <div class="col" style="margin-top:-.7cm;">
                <p>VALIDATION</p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <table class="table" style="border: solid 1px; margin-top: -.3cm;">
                    <tr>
                        <th colspan="6" style="text-align: center; background-color: black; color: white;">School Year</th>
                    </tr>
                    <tr>
                        <td>Grade 7</td>
                        <td>_______</td>
                        <td>Grade 10</td>
                        <td>_______</td>
                    </tr>
                    <tr>
                        <td>Grade 8</td>
                        <td>_______</td>
                        <td>Grade 11</td>
                        <td>_______</td>
                    </tr>
                    <tr>
                        <td>Grade 9</td>
                        <td>_______</td>
                        <td>Grade 12</td>
                        <td>_______</td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="row">
          <p style="font-size: 12px; background-color: black; color: white; font-weight: bold;  margin-top:-.3cm; margin-left:1.5cm;;" align="center" >IN CASE OF EMERGENCY PLEASE NOTIFY:</p>
            <div style="border: 1px solid black; margin-left: .2cm; text-align: center; margin-top: -.2cm; width: 328px; ">
                <p align="center">
                    <input type="text" value="' . $row["Guardian_Name"] . '" id="gname" style="font-size: 13px; font-weight: bold; margin-left: .3cm; margin-top: -.3cm; text-decoration: underline; background: none; border: none; text-align: center; outline: none;" readonly>
                </p>
                <p style="margin-top: -.5cm; font-size: 10px;">
                    <textarea id="addsz" style="resize: none; border: none; background: none; outline: none; text-align:center;" rows="2" cols="30">' . $row["Address"] . '</textarea>
                </p>
                <p align="center" style="margin-top: -.6cm;">
                    <input type="text" value="' . $row["Guardian_Cont"] . '" id="gcont" style="font-size: 15px; font-weight: bold; margin-left: .3cm; text-decoration: underline; background: none; border: none; text-align: center; outline: none;" readonly>
                </p>
            </div>
            <p style="font-size: 10px; text-align: center; margin-left:.3cm;">This ID card certifies that the holder is a bona fide student of <br>PABLO VALENCIA NATIONAL HIGH SCHOOL. Unauthorized use is prohibited.</p>
            <img id="qrcodes" src="qrcode/' . $row["QRcode"] . '" style="width: 100px; margin-left: 3.3cm; margin-top: -.2cm;">
        </div>
        <div class="row" style="margin-top: 1.2cm;">
            <p style="font-size: 15px; font-weight: bold;  margin-top:-.7cm; margin-left : 3cm;" >ROMEO S. JERAO</p>
            <p style="font-size: 15px; font-weight: bold;  margin-top:-.5cm; margin-left : 1.5cm;" >Head Teacher - III / School Head</p>
        </div>
    </div>
</div> <br>' ;
}

        ?>