<?php include 'connection.php'; 


if (!isset($_SESSION['username'])) {
    
    header("Location:index.php");
}
require_once 'phpqrcode/qrlib.php';
$path = 'qrcode/';

require 'vendor/autoload.php';

if (isset($_POST['import'])) {
    $fileName = $_FILES['file']['tmp_name'];

    if ($_FILES['file']['size'] > 0) {
        // Open the CSV file
        if (($handle = fopen($fileName, "r")) !== FALSE) {
            $currentRow = 1; // Track the current row

            // Loop through the rows in the CSV file
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                // Skip the first row (header row)
                if ($currentRow == 1) {
                    $currentRow++;
                    continue; // Skip the header row
                }

                // Extract values from the row (adjust column indices based on your CSV format)
                $s_id = $data[0] ?? '';       // stud_id
                $fname = $data[1] ?? '';      // First_Name
                $mname = $data[2] ?? '';      // Middle_Name
                $lname = $data[3] ?? '';      // Last_Name
                $suffs = !empty($data[4]) ? $data[4] : ''; // Suffix with default
                $gends = $data[5] ?? '';      // Gender
                $agess = $data[6] ?? '';      // Age
                $bdate = $data[7] ?? '';      // Birth_Date
                $bplace = $data[8] ?? '';     // Birth_Place
                $cn = $data[9] ?? '';         // Contact_Num
                $gn = $data[10] ?? '';        // Guardian_Name
                $gc = $data[11] ?? '';        // Guardian_Cont
                $adds = $data[12] ?? '';      // Address
                $batch = $data[13] ?? '';     // Batch (adjusted for correct index)
                $photo = 'uploads/school.png';

                // Check if the student ID already exists in the database
                $checkQuery = "SELECT * FROM `students` WHERE `stud_id` = '$s_id'";
                $checkResult = mysqli_query($conn, $checkQuery);

                if (mysqli_num_rows($checkResult) > 0) {
                    // Skip this row if the student ID already exists
                    $currentRow++;
                    continue;
                }

                // Generate the QR code for the student ID (s_id)
                $qrCodeFileName = $s_id . '.png';  // Name the file based on student ID
                $qrCodeFilePath = $path . $qrCodeFileName; // Full path to save the QR code
                QRcode::png($s_id, $qrCodeFilePath, QR_ECLEVEL_L, 4, 2); // Generate the QR code

                // Insert data into `students` table
                $sqlInsert = "INSERT INTO `students`(`stud_id`, `First_Name`, `Middle_Name`, `Last_Name`, `Suffix`, `Gender`, `Age`, `Birth_Date`, `Birth_Place`, `Contact_Num`, `Guardian_Name`, `Guardian_Cont`, `Address`,  `Photo`,`QRcode`, `Batch`) 
                              VALUES ('$s_id','$fname','$mname','$lname','$suffs','$gends','$agess','$bdate','$bplace','$cn','$gn','$gc','$adds','$photo','$qrCodeFileName','$batch')";
                $result = mysqli_query($conn, $sqlInsert);
                
                $_SESSION['response']="Import File Successfully";
                $_SESSION['type']="success";

                $currentRow++; // Increment the row counter
            }

            // Close the file handle
            fclose($handle);
        }
    }
}
if (isset($_POST['backup'])) {
    // Check if a file was uploaded
    if (isset($_FILES['sqlFile']) && $_FILES['sqlFile']['error'] == 0) {
        // Get file path
        $fileTmpPath = $_FILES['sqlFile']['tmp_name'];

        // Read the SQL file
        $sqlContent = file_get_contents($fileTmpPath);
        if ($sqlContent === false) {
            die("Error reading the uploaded SQL file.");
        }

        // Create a connection
        $conn = new mysqli("localhost", "root", "", "proxy");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Split SQL statements by semicolons
        $sqlStatements = explode(";", $sqlContent);

        // Execute each SQL statement
        $success = true;
        foreach ($sqlStatements as $query) {
            $query = trim($query); // Remove whitespace
            if (!empty($query)) {
                if (!$conn->query($query)) {
                    $success = false;
                    echo "Error executing query: " . $conn->error . "<br>";
                }
            }
        }
   $_SESSION['response']="Import Database Successfully";
                $_SESSION['type']="success";

        // Close the connection
        $conn->close();
    } else {
        echo "File upload failed. Please try again.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/logo.png" rel="icon">
  <title>Brgy Poblacion Profiling/Management System</title>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>

<body id="page-top">
  
  <?php include 'includes/navbars.php'; ?>
        <!-- Topbar -->

        <!-- Container Fluid-->
       <!-- DataTable with Hover -->
       <div class="col-lg-12">
      <?php if(isset($_SESSION['response'])){ ?>
<div class="alert alert-<?= $_SESSION['type']; ?> alert-dismissible">
  <button type="button" class="close" data-dismiss="alert">&times </button>
  <?= $_SESSION['response']; ?>
  </div>
<?php  unset($_SESSION['response']); 
} ?>
</div>


            <div class="col-lg-12">
              <div class="card mb-4">

                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">

                  <h6 class="m-0 font-weight-bold text-primary">IMPORT SETTINGS</h6>

                </div>
                   <div id="overlayactive" style="display:none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>



              </div>
            </div>
        <div class="row">
    <div class="col">
        <div class="card-body table-responsive">
            <form enctype="multipart/form-data" method="POST">
                      <label style="font-family: Courier New;">Import CSV File:</label>
                <div class="input-group">
           
                    <input type="file" name="file" class="form-control">
                    <div class="input-group-append">
                        <button type="submit" name="import" class="btn btn-success">Import</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="col">
        <div class="card-body table-responsive">
           <div class="col">
      
            <form enctype="multipart/form-data" method="POST">
                  <label style="font-family: Courier New;">Import Database:</label>
                <div class="input-group">
               
                    <input type="file" name="sqlFile" class="form-control">
                    <div class="input-group-append">
                        <button type="submit" name="backup" class="btn btn-success">Import</button>
                    </div>
                </div>
            </form>
       
    </div>
        </div>
    </div>
  </div>
</div>
          <!--MODAL FOR HOUSEHOLD--->
      

 <!--EDIT MODAL FOR HOUSEHOLD--->

<!---END-->

        <!-- Modal delete -->




          <!-- Modal Logout -->
          <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <div id="overlays1" style="display:none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>
                  <p>Are you sure you want to logout?</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <a href="logout.php" class="logout btn btn-primary">Logout</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>copyright &copy; <script> document.write(new Date().getFullYear()); </script> - developed by
              <b><a  target="_blank"><?php echo $_SESSION['Fullname']; ?></a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
 
 
</body>

</html>
  <script type="text/javascript">
  $(document).ready(function() {
  $('.submit').click(function(){
    $('#overlay').fadeIn().delay(2000).fadeOut();
  });
  $('.update').click(function(){
    $('#overlays').fadeIn().delay(2000).fadeOut();
  });
   $('.deleteb').click(function(){
    $('#overlay2').fadeIn().delay(2000).fadeOut();
  });
  $('.logout').click(function(){
    $('#overlays1').fadeIn().delay(2000).fadeOut();
  });
  $('.spin').click(function(){
    $('#overlayactive').fadeIn().delay(2000).fadeOut();
  });
});
</script>
<style type="text/css">
   #overlay {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlayactive {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlay2 {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlays1 {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlays {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}

.spinner {
    margin: 0 auto;
    height: 64px;
    width: 64px;
    animation: rotate 0.8s infinite linear;
    border: 5px solid firebrick;
    border-right-color: transparent;
    border-radius: 50%;
}
@keyframes rotate {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}
</style>