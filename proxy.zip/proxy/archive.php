<?php include 'connection.php'; 

if (!isset($_SESSION['username'])) {
    
    header("Location:index.php");
}


  if(isset($_POST['return'])){
    $id = $_POST['myidsz'];
    $sqls = "INSERT into students(SELECT * from archive WHERE a_id='$id')";
    $stmt = $conn -> prepare($sqls);
    $stmt ->execute();
    $sql = "DELETE FROM archive WHERE a_id='$id'";
    $stmt = $conn -> prepare($sql);
    $stmt ->execute();



          $_SESSION['response']="Data has been returned to Students Informationn";
    $_SESSION['type']="success";
      
    }
     if(isset($_POST['delete'])){
    $id = $_POST['myids'];
    $sql = "DELETE FROM archive WHERE a_id='$id'";
    $stmt = $conn -> prepare($sql);
    $stmt ->execute();


          $_SESSION['response']="Information transfered to archived";
    $_SESSION['type']="danger";
    }
?>





<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Brgy Poblacion Profiling/Management System</title>

  <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
  
</head>  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
  <link href="css/spinner.css" rel="stylesheet">
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

<body id="page-top">

  <div id="loader-wrapper">
      <div id="loader"></div>        
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
  </div>

  <?php include 'includes/navbars.php'; ?>

        <!-- Topbar -->

        <!-- Container Fluid-->
       <!-- DataTable with Hover -->
        <div class="col-lg-12">
      <?php if(isset($_SESSION['response'])){ ?>
<div class="alert alert-<?= $_SESSION['type']; ?> alert-dismissible">
  <button type="button" class="close" data-dismiss="alert">&times </button>
  <?= $_SESSION['response']; ?>
  </div>
<?php  unset($_SESSION['response']); 
} ?>
</div>
      



            <div class="col-lg-12">

              
              <div class="card mb-4">
             
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">

                  <h6 class="m-0 font-weight-bold text-primary">ARCHIVE</h6>
                </div>
                  

                        
                <div class="table-responsive p-3">
       
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                
                     <?php
$query = "SELECT * FROM archive";
$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();
?>  
                    <thead>
                    <tr>
                      <th style="display: none;"></th>
                        <th>#</th>
                        <th>STUDENT LRN</th>
                          <th>Fullname</th>
                        <th  style="display: none;">First Name</th>
                        <th  style="display: none;">Middle Name</th>
                        <th  style="display: none;">Last Name</th>
                        <th  style="display: none;">Suffix</th>
                        <th  style="display: none;">Gender</th>
                        <th  style="display: none;">Age</th>
                        <th  style="display: none;">Birth Date</th>
                        <th  style="display: none;">Birth Place </th>
                        <th  style="display: none;">Contact Number</th>
                        <th>Guardian Name</th>
                        <th>Guardian Contact</th>
                             <th  style="display: none;">Photo</th>
                     <th  style="display: none;">Photo</th>
                       <th  style="display: none;">QR</th>
                        <th>Batch</th>
            <th>Action</th>
                    </tr>
                </thead>

             
                   <tbody>
                     <?php 
        $i = 1;
        while ($row = $result->fetch_assoc()) {

                             $c = $row['Middle_Name'];
             $d = !empty($c) ? substr($c, 0, 1) . '.' : ''; ?>
            <tr>
                <td style="display: none;"><?=$row['a_id']?></td>
                      <td><?php echo $i++ ?></td>
                      <td><?=$row['stud_id']?></td>
                      <td><?=$row['First_Name'] . " " . $d . " " . $row['Last_Name'] . " " . $row['Suffix']; ?></td>
                      <td  style="display: none;"><?=$row['First_Name']?></td>
                      <td  style="display: none;"><?=$row['Middle_Name']?></td>
                      <td  style="display: none;"><?=$row['Last_Name']?></td>
                      <td  style="display: none;"><?=$row['Suffix']?></td>
                      <td  style="display: none;"><?=$row['Gender']?></td>
                      <td  style="display: none;"> <?=$row['Age']?></td>
                      <td  style="display: none;"><?=$row['Birth_Date']?></td>
                      <td  style="display: none;"><?=$row['Birth_Place']?></td>
                      <td  style="display: none;"><?=$row['Contact_Num']?></td>
                      <td><?=$row['Guardian_Name']?></td>
                      <td><?=$row['Guardian_Cont']?></td>
                          <td style="display: none;"><?=$row['Address']?></td>
                           <td  style="display: none;"><?=$row['Photo']?></td>
                           <td  style="display: none;"><?=$row['QRcode']?></td>
                      <td><?=$row['Batch']?></td>
                <td>        <a href="#returnModal" class="return badge text-bg-success p-2" ><i class=" fas fa-external-link-alt fa-2x"></i> </a>
       
    </a> | <a href="#deleteModals" class="delete badge text-danger p-2" ><i class="  fab fa-confluence fa-2x"></i> </a>
                </td>
            </tr>
          <?php } ?>
                </tbody>

                  </table>

                </div>

    
              </div>

            </div>

             

          <!--MODAL FOR STUDENTS--->
<div class="modal fade" id="returnModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                         <div id="overlay2" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
                  <form action="" method="post">
                  <input type="hidden" name="myidsz" id="myidsz">
                  <center><p>Are you sure you want to recover this data?</p>
                    <h4><b>Student Name:</b></h4><h4 id="dataaz"></h4></center>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <button type="submit" class="deleteb btn btn-success" name="return">Recover</button>
                </div>
              </form>
              </div>
            </div>
          </div>
        

<!---END-->


  <!--MODAL FOR EDIT HOUSEHOLD--->
    <div class="modal fade" id="deleteModals" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                         <div id="overlay2" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
                  <form action="" method="post">
                  <input type="hidden" name="myids" id="myids">
                  <center><p>Are you sure you want to delete this data?</p>
                    <h4><b>Student Name:</b></h4><h4 id="dataa"></h4></center>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <button type="submit" class="deleteb btn btn-danger" name="delete">Delete</button>
                </div>
              </form>
              </div>
            </div>
          </div>
        
<!---END-->


 


 <!-- Modal delete -->


          <!-- END -->


<!-- Modal for generating IDs by Batch -->
>


          <!-- Modal Logout -->
          <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                     <div class="modal-body">
                      <div id="overlays1" style="display: none;">
    <div class="spinner"></div>
    <br/>
    Loading...
</div>  
                  <p>Are you sure you want to logout?</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <a href="logout.php" class="logout btn btn-primary">Logout</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>copyright &copy; <script> document.write(new Date().getFullYear()); </script> - developed by
              <b><a  target="_blank"><?php echo $_SESSION['Fullname']; ?></a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
  
  <!-- Page level custom scripts -->
  <script>
    $(document).ready(function () {

      $('#dataTable').DataTable(); 
      $('#dataTableHover').DataTable();


$(document).on('click', '.delete', function (e) {
      $('#deleteModals').modal('show');
      $tr = $(this).closest('tr');
      var data= $tr.children("td").map(function(){
        return $(this).text();

      }).get();
      console.log(data);
          let fullNamez = `${data[4]}  ${data[5].charAt(0)}. ${data[6] } ${data[7]}`;
      $('#dataa').html(fullNamez);
      $('#myids').val(data[0]);
      });

               $('a.return').on('click', function(){
      $('#returnModal').modal('show');
      $tr = $(this).closest('tr');
      var data= $tr.children("td").map(function(){
        return $(this).text();

      }).get();
      console.log(data);
          let fullNamez = `${data[4]}  ${data[5].charAt(0)}. ${data[6] } ${data[7]}`;
      $('#dataaz').html(fullNamez);
      $('#myidsz').val(data[0]);
      });
});
</script>



  <script type="text/javascript">
  $(document).ready(function() {
  $('.submit').click(function(){
    $('#overlay').fadeIn().delay(2000).fadeOut();
  });
  $('.update').click(function(){
    $('#overlays').fadeIn().delay(2000).fadeOut();
  });
   $('.deleteb').click(function(){
    $('#overlay2').fadeIn().delay(2000).fadeOut();
  });
  $('.logout').click(function(){
    $('#overlays1').fadeIn().delay(2000).fadeOut();
  });
});
</script>
 <style type="text/css">
   th{
    font-size: 12px;
   }
   td{
    font-size: 13px;
   }
   #overlay {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlay2 {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlays1 {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}
 #overlays {
  background: #ffffff;
  color: #666666;
  position: fixed;
  height: 100%;
  width: 100%;
  z-index: 5000;
  top: 0;
  left: 0;
  float: left;
  text-align: center;
  padding-top: 20%;
  opacity: .80;
}

.spinner {
    margin: 0 auto;
    height: 64px;
    width: 64px;
    animation: rotate 0.8s infinite linear;
    border: 5px solid firebrick;
    border-right-color: transparent;
    border-radius: 50%;
}
@keyframes rotate {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}
 </style>

 <style type="text/css">
    .div-container {
    border: solid 4px black;
    width: 150px;
    height: 50px;
    background-image: url('assets/img/school_building.png');

    background-position: center; /* This centers the image within the div */
}
</style>

</body>

</html>